zHeave=[zHeave;inputFromCpp];

save("matlabSession.mat","ii","zHeave");

outputToCpp = 0;
